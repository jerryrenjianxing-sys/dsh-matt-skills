---
name: codebase-design
description: fixture skill v1.3.2
---

# codebase-design

